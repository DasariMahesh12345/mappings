package objects;

import org.openqa.selenium.WebDriver;

public class LunchApp {
	
	public static WebDriver driver;
	
	public LunchApp(WebDriver driver) {
		this.driver=driver;
	}
		


}
