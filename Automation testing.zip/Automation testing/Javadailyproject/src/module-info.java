/**
 * 
 */
/**
 * 
 */
module Javadailyproject {
}