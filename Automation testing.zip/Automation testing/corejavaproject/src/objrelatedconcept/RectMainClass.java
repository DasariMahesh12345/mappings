package objrelatedconcept;

public class RectMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      //referance create avtundhi variale ki memory create avtundhi refrence value indicating object 2342
		Recct re =new Recct();
		Recct re1 =new Recct();
		
		
		//Recct re; // here only create reference valiable 2342
		
		re.n1();
		re.n2();
		 
		
		
		
	}

}
