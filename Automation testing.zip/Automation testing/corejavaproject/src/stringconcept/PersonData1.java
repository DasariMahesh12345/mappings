
package stringconcept;

import java.util.Scanner;

public class PersonData1 {

	// public static void main(String[] args) {
	

	String name;
	String address;
	String pan;// variables int age; }
    int age;
    
	public void m1()
	
	{
		Scanner scr = new Scanner(System.in);
		System.out.print("Enter Name:");
		name = scr.nextLine();
		System.out.print("\nEnter Address:");
		address = scr.nextLine(); // input data
		System.out.print("\nEnter Pan:");
		pan = scr.nextLine();
		System.out.print("\nEnter Age:");
		age = scr.nextInt();
		System.out.println();
		scr.nextLine();
		
		
	}

	void m2() {

		System.out.println("\nPerson Name    : " +name);
		System.out.println("Person Address : " + address);
		System.out.println("Person Pan     : " + pan); // output data
		System.out.println("Person Age     : " + age);
		System.out.println("\n");

	}
	
	 }
