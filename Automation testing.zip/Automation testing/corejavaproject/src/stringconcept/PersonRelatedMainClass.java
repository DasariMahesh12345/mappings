package stringconcept;

public class PersonRelatedMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  PersonData1 per = new PersonData1();
		  per.m1(); //e model lo rasthy 1st 1st input tesukoni at atime output estundhi
		  per.m2(); 
		  PersonData1 per1 = new
		  PersonData1();
		  per1.m1();
		  per1.m2();
		 
		
		 
		PersonData1 per2 = new PersonData1();
		PersonData1 per3 = new PersonData1();
		per2.m1();
		per3.m1();
		
		
		per2.m2();                    // e mosel lo rasthya 1 st 2 inputs tesukoni next 2 outputs estundhi
		per3.m2();
		
	}

}
