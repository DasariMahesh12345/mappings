package stringconcept;

public class StringMethods {

	public static void main(String[] Mahesh) {
		
		System.out.println("hello");
		
		int    a=25;
		double b=3.45;
		String c = "siva";
		String d = "pavan muppidi";
		String e = "siva rama krishna";
		String s = "";
		
		String name = "MAHESH";
		
		String loeCase = "prasanna";
		
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
		System.out.println();
		System.out.println(c.length());//4
		System.out.println(d.length());//13
		System.out.println(e.length());//17
		System.out.println("no of string count : "+c+" are "+c.length()); // 4 //print c length//,// siva are 4 ,
		System.out.println("no of string count : '"+d+"' are "+c.length()); //13  //name put in single quate, // 'pavan muppidi' are 4, 
		System.out.println("no of string count : \""+e+"\" are "+c.length());//17  //name put in double quate,//"siva rama krishna" are 4 
		System.out.println(c.indexOf('s')); //character a position lo vundho cheptundhi       // in siva name "s"index position print
		System.out.println(d.indexOf('m'));         // in pavan muppidi "m" index position print
		System.out.println(d.indexOf('r'));        //  in ""     ""    "r" not present so uot put -1
		System.out.println(e.indexOf('a'));        //0, // in siva rama krishna name lo no of "a" lu vunna starting nundi 1 st "a" consider chasi print chastundhi 
		System.out.println(e.indexOf('a',5));     //6// "a" char ni 5th locatin nundi chudu ani 
		System.out.println(e.indexOf('a',11));   //-1 //  start searching 11 location
	
		System.out.println(e.lastIndexOf('a'));     //16 output, a anni times vunna last vunnadhi consider chastundhi
		System.out.println(e.lastIndexOf('a',14));  //8 output, 14 nundi back ki chudu ani meaning 
		System.out.println(c.indexOf("siva")); // c variable lo siva present so o/p 0
		System.out.println(d.indexOf("siva"));//d  variable lo siva not present so o/p -1
		System.out.println(e.charAt(5));// 5th position r present o/p r
		//System.out.println(c.charAt(8));// not o/p getting exception
		System.out.println(e.startsWith(c));// o/p true y because e start with siva c start with siva
		System.out.println(e.startsWith("rama"));// false 
		System.out.println("india".startsWith("in"));// true
		System.out.println("india".startsWith("id"));//false 
		System.out.println("INDIA".startsWith("india"));// false y because caps small diff
		System.out.println();
		System.out.println("india".endsWith("in"));// false
		System.out.println("india".endsWith("ia"));// true
		System.out.println(e.endsWith("hna"));// true
		System.out.println(e.endsWith("rama"));// false
		
		System.out.println();
		System.out.println(c.equals(e));// false
		System.out.println(c.equals(c));// true
		System.out.println();
		System.out.println("siva".equals(c));// true
		System.out.println("siva".equals("c"));//false y because c variable put in "" cotes
		System.out.println("SIVA".equals(c));// false y because "SIVA" CAPES LO VUNDHI c avariable lo small lo vundhi
		
		System.out.println("SIVA".equals("siva"));// false
		System.out.println("SIVA".equalsIgnoreCase("siva"));//true 		
		System.out.println("SIVA".equalsIgnoreCase(c));// true
		System.out.println();
		String f = d.substring(0, 3);  //pav  charecter o to 3 
		System.out.println(f);
		String g = e.substring(4, 9); // rama  charecter 4 to 9 
		System.out.println(g);
		System.out.println();
		System.out.println(c.compareTo(d));//A starts with 65 AIIS KEY VALUES
		System.out.println(c.compareTo(e));//a starts with 97
		System.out.println(d.compareTo(e));
		System.out.println("INDIA".compareTo("INDIA")); // O/P 0
		System.out.println("INDIA".compareTo("india")); // o/p -31 (small and caps same string diffrence -32)
		System.out.println("INDIA".compareToIgnoreCase("india"));// o/p 0
		// trim() method is used to string before and after spaces remove
		System.out.println(name);
		System.out.println(name.toLowerCase());
		System.out.println(loeCase.toUpperCase());
		String x= name.replace("A","J"); //MJHESH
		System.out.println(x);
		String y= name.replace("H","Jdfgsdf");// NOTE dont put small letter var lo em vunty adhy pettali
		System.out.println(name); //MAHESH
		System.out.println(y);
		name=name.replace("S", "dsfkdhjk");
		System.out.println(name);
		System.out.println(s.isEmpty());// true
		System.out.println(e.isEmpty());// false
		
		System.out.println();
		
		c=c.concat(e);
		System.out.println(c); //sivasiva rama krishna
		 
		String w= c+" " +" "+ e;
		System.out.println(w);//sivasiva rama krishna siva rama krishna
	}

}
