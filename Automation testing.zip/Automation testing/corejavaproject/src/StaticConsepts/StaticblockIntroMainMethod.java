package StaticConsepts;

public class StaticblockIntroMainMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticBlockintroducton ob1 = new StaticBlockintroducton();
		StaticBlockintroducton ob2 = new StaticBlockintroducton("\nmahesh","hyd",30);
		StaticBlockintroducton ob3 = new StaticBlockintroducton("mahesh","hyd");
		StaticBlockintroducton ob4 = new StaticBlockintroducton("mahesh");
		
				
		
	 ob1.print();
	 ob2.print();
	 ob3.print();
	 ob4.print();
	}

}
