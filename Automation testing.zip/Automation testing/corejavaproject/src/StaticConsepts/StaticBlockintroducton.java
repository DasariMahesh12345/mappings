package StaticConsepts;

public class StaticBlockintroducton {
	
	String name;
	String location;
	int age;
	
	StaticBlockintroducton(){
		System.out.println("default constriuctor");
	}
	public StaticBlockintroducton(String n, String m,int y) {
		// TODO Auto-generated constructor stub
		name=n;
		location=m;
		age=y;
		System.out.println(name+"  "+location+" "+age);
	}
	

	public StaticBlockintroducton(String n, String m) {
		// TODO Auto-generated constructor stub
		this(n,m,2042);
	}
	public StaticBlockintroducton(String n) {
		// TODO Auto-generated constructor stub
		this(n,"manu");
	}
		void print(){
			System.out.println(name);
			System.out.println(location);
			System.out.println(age);
			
		}
	}


