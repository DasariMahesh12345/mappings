package com.practice.ehr.PN.pending.items.to.continu;

public class PnPendingListToContinue {

}
