package com.practice.Axces;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import net.bytebuddy.asm.Advice.Argument;

public class TestAxces {
	static WebDriver driver;

	@Test
	public void axcesMethod() throws Exception {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.w3schools.com/");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[2]/div[1]/nav/a[2]")).click();
}
	

/*
 * public static void heilight(WebElement element) { JavascriptExecutor
 * jsExecuter= (JavascriptExecutor)driver ; jsExecuter.
 * executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;')"
 * ,element); }
 */
}
